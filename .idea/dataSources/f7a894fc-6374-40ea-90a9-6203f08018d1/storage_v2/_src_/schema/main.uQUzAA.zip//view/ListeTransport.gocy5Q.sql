CREATE VIEW ListeTransport(date_voyage, type_transport, numero_transport, ville_depart, ville_arrivee, id_voyage) as
    select
        Dossier.date,
        (CASE
            WHEN  Dossier.id_voyage < 100 then 'avion'
            WHEN Dossier.id_voyage < 200 then 'train'
            WHEN Dossier.id_voyage < 300 then 'bus'
            ELSE 'null'
        END) as type_transport,
        (CASE
            WHEN  Dossier.id_voyage < 100 then (select VoyageEnAvion.code_avion from VoyageEnAvion WHERE VoyageEnAvion.id_avion = Dossier.id_voyage)
            WHEN Dossier.id_voyage < 200 then (select VoyageEnTrain.code_train from VoyageEnTrain WHERE VoyageEnTrain.id_train = Dossier.id_voyage)
            WHEN Dossier.id_voyage < 300 then (select VoyageEnBus.code_bus from VoyageEnBus WHERE VoyageEnBus.id_bus = Dossier.id_voyage)
            ELSE 'null'
        END) as numero_transport,
        /*ville départ*/
        Dossier.depart,
        /*ville arrivee*/
        Dossier.arrivee,
        Dossier.id_voyage
    FROM Dossier
    GROUP BY Dossier.depart, Dossier.arrivee, Dossier.id_voyage, Dossier.date;

