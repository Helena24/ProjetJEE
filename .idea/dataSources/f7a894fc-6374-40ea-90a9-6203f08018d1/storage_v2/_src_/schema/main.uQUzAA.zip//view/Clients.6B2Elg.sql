CREATE VIEW Clients(id_voyageur,nom,prenom,telephone,mail) as
    select  id_voyageur,nom, prenom,
    (select valeur as telephone from Contact where methode='telephone' and Voyageur.id_voyageur = Contact.id_voyageur),
    (select valeur as email from Contact where methode='mail' and Voyageur.id_voyageur = Contact.id_voyageur)
    from Contact join Voyageur using(id_voyageur) group by id_voyageur;

