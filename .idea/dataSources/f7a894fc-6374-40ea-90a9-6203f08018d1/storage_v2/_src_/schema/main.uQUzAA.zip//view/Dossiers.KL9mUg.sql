CREATE VIEW Dossiers(referenceClient, referenceVoyage, voyageEffectue) as
    select Dossier.id_voyageur, Dossier.id_voyage,
    (CASE
        WHEN NonPartantAvion.id_voyageur = Dossier.id_voyageur AND Dossier.methode = 'avion' then 'non'
        WHEN NonPresentTrain.id_dossier = Dossier.id_dossier AND Dossier.methode='train' then 'non'
        ELSE 'oui'
        END) AS 'voyageEffectue'
        from NonPartantAvion,Dossier,NonPresentTrain;

